window.onload = function () {
  var hichat = new HiChat();
  hichat.init();

}

//HiChat类
var HiChat = function () {
  this.socket = null;
}

HiChat.prototype = {
  init: function () {
    var that = this;
    //io就是我们的socket对象，调用了我们的connect方法，和服务器连接上
    this.socket = io.connect();
    this.socket.on('connect', function () {
      document.getElementById('info').textContent = '输入您的昵称';
      document.getElementById('nickWrapper').style.display = 'block';
      document.getElementById('nicknameInput').focus();
    });

    this.socket.on('nickExisited', function () {
      document.getElementById('info').textContent = '你的名称已经存在了，请重新输入';
    });

    this.socket.on('system', function (nickName, userCount, type) {
      console.log('1');
      var msg = `${nickName} ${type == 'login' ? '来到聊天室' : '离开了'}`;
      that._displayNewMsg('系统', msg, 'red');
      document.getElementById('status').textContent = `${userCount} +位用户在线`;

    });

    this.socket.on('loginSuccess', function () {
      document.title = 'hichat |'
        + document.getElementById('nicknameInput')
          .value;
      document.getElementById('loginWrapper').style.display = 'none';
      document.getElementById('messageInput').focus();


    });

    document.getElementById('loginBtn')
      .addEventListener('click', function () {
        var nickname = document.getElementById('nicknameInput').value;
        if (nickname.trim().length != 0) {
          //激发事件
          //我有login需求，服务器你来满足我呗？
          that.socket.emit('login', nickname);
        } else {
          document.getElementById('nicknameInput').focus();
        }
      }, false);
  },
  _displayNewMsg: function(user, msg, color) {
      var container = document.getElementById('historyMsg'),
      msgToDisplay = document.createElement('p');
      date = new Date().toTimeString().substr(0, 8);

      msgToDisplay.style.color = color || '#000';
      msgToDisplay.innerHTML = `${user}<span class="timespan">(${date}):</span>${msg}`;
      container.appendChild(msgToDisplay);
      container.scrollTop = container.scrollHeight;
    }
}
// window.onload = function() {
//   var hichat = new HiChat();
//   hichat.init();
// }
// // HiChat类
// var HiChat = function() {
//   this.socket = null;
// }
// HiChat.prototype = {
//   init: function() {
//     var that = this;
//     // io就是我们的socket对象，调用connect方法
//     // 跟服务器端连接上。
//     this.socket = io.connect();
//     this.socket.on('connect', function(){
//       document.getElementById('info').textContent = '输入您的昵称';
//       document.getElementById('nickWrapper').style.display = 'block';
//       document.getElementById('nicknameInput').focus();
//     });
//     this.socket.on('login',function(nickName,userCount,type) {
//       var msg = `${nickName} ${type=='login'?'来到聊天室':'离开了'}`;
//       this._displayNewMsg('系统',msg,'red');
//       document.getElementById('status').textContent = `${userCount} +位用户在线`;

//     });
//     this.socket.on('loginSuccess', function(){
//       document.title = 'hichat | '
//         + document.getElementById('nicknameInput').value;
//       document.getElementById('loginWrapper').style.display = 'none';
//       document.getElementById('messageInput').focus();
//     });
//     this.socket.on('nickExisted', function() {
//         document.getElementById('info').textContent
//          = '亲，昵称已占用！换个呗';
//     });
//     document.getElementById('loginBtn')
//       .addEventListener('click', function() {
//         var nickName = document.getElementById('nicknameInput').value;
//         if(nickName.trim().length != 0) {
//           that.socket.emit('login', nickName);
//         } else {
//           document.getElementById('nicknameInput').focus();
//         }
//       }, false);
//   },
//   _displayNewMsg: function(user, msg, color){
//     var container = document.getElementById('historyMsg'),
//       msgToDisplay = document.createElement('p');
//       data = new Date().toTimeString().substr(0,8);

//     msgToDisplay.style.color = color || '#000';
//     msgToDisplay.innerHTML = `${user}<span class="timespan">(${date}):</span>${msg}`;
//     container.appendChild(msgToDisplay);
//     container.scrollTop = container.scrollHeight;
//   }
// }