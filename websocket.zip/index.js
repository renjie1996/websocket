const express = require('express');
const app = express();
const server = require('http').createServer(app);

//有多少人进入了聊天室
const users = [];

// socket.io是websocket html5 开发实时项目的利器 
// js前端后端 
// socket实时通信协议，QQ，游戏
//基于web server上再构建的一层websocket
const io = require('socket.io').listen(server);

// 唯一的静态文件中间件
app.use('/',express.static(__dirname + '/www'));

server.listen('3000',function(){
  console.log("listening in port:3000")
});

//socket.io将websocket协议抽象出来的事件 message
//工作的开始
io.sockets.on('connection',function(socket){
  console.log('connection');
  socket.on('login', function(nickname) {
    // includes??????
  console.log(nickname);
  if(users.indexOf(nickname) > -1){
      console.log('重名了');
      socket.emit('nickExisited');
  } else {
    console.log(nickname);
    socket.nickname = nickname;
    users.push(nickname);
    socket.emit('loginSuccess');
     io.sockets.emit('system', nickname, users.length, 'login');

  }
  })
})

// // app.get('/',function(req,res) {
// //   res.send('hichat');
// // });
// // app.listen('3000',function(){
// //   console.log("listening in port:3000")
// // })
// const express = require('express');
// const app = express();
// const server = require('http').createServer(app);
// const users = [];
// // socket.io 是 websocket html5 开始实时项目的利器
// // js 前端后端通用， 所以socket.io 非常流行。
// // socket 实时通信协议，QQ 游戏
// // 基于web server上再构建的一层websocket
// const io = require('socket.io').listen(server);
// app.use('/', express.static(__dirname + '/www'));
// server.listen(8081);
// // socket.io 将 websocket协议抽像出来的事件 message
// io.sockets.on('connection',function(socket) {
//   socket.on('login', function(nickname) {
//     if(users.indexOf(nickname) > -1) {
//       console.log(nickname + '重名了');
//       socket.emit('nickExisted');
//     } else {
//       socket.nickname = nickname;
//       users.push(nickname);
//       // console.log(nickname)
//       socket.emit('loginSuccess');
//       io.sockets.emit('system', nickname, users.length, 'login');
//     }

//   });
// })